## PARA EL CORRECTO FUNCIONAMIENTO DEL SISTEMA.

---

**Creación de roles de usuarios** | <a href="./request.http">POST DE ROL</a>

Se requiere tres roles de usuarios para el sistema: ADMINISTRADOR, DENTISTA, PACIENTE

---

**Creación de consultorio por Admin** | <a href="./request.http">POST DE CONSULTORIO</a>

Se requiere la creación de un consultorio previo por administrador

---

**Creación de usuario Admin** | <a href="./request.http">POST DE USUARIO ADMIN</a>

Se requiere la creación de un usuario administrador por consultorio

---

**Creación de data de user Admin** | <a href="./request.http">POST DE DATA USER ADMIN</a>

Se requiere la creación de datos del user admin creado